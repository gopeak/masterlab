<?php

$_config = 
array (
  'ios' => 
  array (
    'version' => '1.0',
    'content' => '正式版发布!',
    'url' => 'https://',
    'download_url' => 'http://www.masterlab.vip/?_f=download',
  ),
  'android' => 
  array (
    'version' => '1.0',
    'content' => '正式版发布!',
    'url' => 'http://',
    'download_url' => 'http://www.masterlab.vip/?_f=download',
  ),
);

return $_config;
<div class="procedure-nav">
    <div class="schedule-ico">
        <span class="a"></span>
        <span class="b"></span>
        <span class="c"></span>
        <span class="d"></span>
    </div>
    <div class="schedule-point-now">
        <span class="a"></span>
        <span class="b"></span>
        <span class="c"></span>
        <span   class="d"></span>
    </div>
    <div class="schedule-point-bg">
        <span class="a"></span>
        <span class="b"></span>
        <span class="c"></span>
        <span class="d"></span>
    </div>
    <div class="schedule-line-now"><em></em></div>
    <div class="schedule-line-bg"></div>
    <div class="schedule-text">
        <span class="a">检查安装环境</span>
        <span class="b">异步,Redis服务</span>
        <span class="c">创建数据库</span>
        <span  class="d">安装</span>
    </div>
</div>
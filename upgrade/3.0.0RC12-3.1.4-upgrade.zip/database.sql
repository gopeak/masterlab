ALTER TABLE `issue_filter` ADD `adv_query_sort_field` VARCHAR(40) NOT NULL DEFAULT '' COMMENT '高级查询的排序字段' AFTER `is_adv_query`, ADD `adv_query_sort_by` VARCHAR(12) NOT NULL DEFAULT 'desc' COMMENT '高级查询的排序' AFTER `adv_query_sort_field`;

ALTER TABLE `project_gantt_setting` ADD `is_check_date`  tinyint(1) unsigned zerofill NOT NULL DEFAULT '1' COMMENT '是否检查开始和结束日期';

ALTER TABLE `project_gantt_setting` ADD `is_check_date`  tinyint(1) unsigned zerofill NOT NULL DEFAULT '1' COMMENT '是否检查开始和结束日期';

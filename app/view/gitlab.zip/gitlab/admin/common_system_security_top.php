<div class="top-area">
    <ul class="nav-links issues-state-filters">
        <li class="<? if($top_active=='project_role') echo 'active';?>">
            <a id="state-opened" title="Filter by issues that are currently opened." href="/admin/system/project_role"><span>项目角色</span>
            </a>
        </li>
        <li class="<? if($top_active=='global_permission') echo 'active';?>">
            <a id="state-all" title="Filter by issues that are currently closed." href="/admin/system/global_permission"><span>全局权限</span>
            </a>
        </li>
        <li class="<? if($top_active=='password_strategy') echo 'active';?>">
            <a id="state-all" title="Show all issues." href="/admin/system/password_strategy"><span>密码策略</span>
            </a>
        </li>
        <li class="<? if($top_active=='user_session') echo 'active';?>">
            <a id="state-all" title="Show all issues." href="/admin/system/user_session"><span>用户会话</span>
            </a>
        </li>
    </ul>
</div>
<div >
    <p>您好 <a href="mailto:{{email}}" target="_blank">{{email}}</a>!</p>
    <p>
        感谢您注册 {{ssite_name}}，请点击以下链接激活账号
    </p>
    <p><a href="{{url}}" target="_blank">{{url}}</a></p>

    <p>如果你没有请求重置密码，请忽略这封邮件.</p>
    <p>在你点击上面链接修改密码之前，你的密码将会保持不变</p>
    <br><br>
</div>
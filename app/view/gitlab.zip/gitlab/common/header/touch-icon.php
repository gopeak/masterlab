
<!--
<link rel="apple-touch-icon" type="image/x-icon" href="<?=ROOT_URL?>gitlab/assets/touch-icon-iphone.png" />
<link rel="apple-touch-icon" type="image/x-icon" href="<?=ROOT_URL?>gitlab/assets/touch-icon-ipad.png" sizes="76x76" />
<link rel="apple-touch-icon" type="image/x-icon" href="<?=ROOT_URL?>gitlab/assets/touch-icon-iphone-retina.png" sizes="120x120" />
<link rel="apple-touch-icon" type="image/x-icon" href="<?=ROOT_URL?>gitlab/assets/touch-icon-ipad-retina.png" sizes="152x152" />
-->
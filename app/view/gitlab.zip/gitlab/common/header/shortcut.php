

<link rel="shortcut icon" type="image/x-icon" href="<?=ROOT_URL?>gitlab/assets/favicon.ico" id="favicon" />
<link color="rgb(226, 67, 41)" href="<?=ROOT_URL?>gitlab/assets/logo.svg" rel="mask-icon">
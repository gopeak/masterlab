<? require_once VIEW_PATH.'gitlab/common/header/meta.php';?>
<? require_once VIEW_PATH.'gitlab/common/header/js.php';?>
<? require_once VIEW_PATH.'gitlab/common/header/stylesheet.php';?>
<? require_once VIEW_PATH.'gitlab/common/header/shortcut.php';?>
<? require_once VIEW_PATH.'gitlab/common/header/touch-icon.php';?>

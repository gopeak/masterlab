<div class="container footer-container">
    <div class="footer-links">
        <a href="https://github.com/gopeak/masterlab">github</a>
        <a href="http://www.masterlab.vip/help.php">帮助</a>
        <a href="http://www.masterlab.vip">官网</a>
    </div>
</div>

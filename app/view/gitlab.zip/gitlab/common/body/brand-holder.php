<div class="col-sm-7 brand-holder pull-left">
    <h1>
        MasterLab 社区版
    </h1>
   <!-- <h4>基于敏捷开发和全生命周期的项目管理工具</h4>-->
    <p>
        基于事项驱动和敏捷开发的项目管理工具，参考Jira和Gitlab优秀特性发展而来。适用于互联网团队进行高效协作和敏捷开发，交付极致卓越的产品
    </p>
</div>
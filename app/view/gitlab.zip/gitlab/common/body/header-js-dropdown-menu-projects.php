<div class="js-dropdown-menu-projects">
    <div class="dropdown-menu dropdown-select dropdown-menu-projects">
        <div class="dropdown-title">
            <span>Go to a project</span>
            <button class="dropdown-title-button dropdown-menu-close" aria-label="Close" type="button"><i class="fa fa-times dropdown-menu-close-icon"></i></button>
        </div>
        <div class="dropdown-input">
            <input type="search" id="" class="dropdown-input-field" placeholder="Search your projects" autocomplete="off">
            <i class="fa fa-search dropdown-input-search"></i>
            <i role="button" class="fa fa-times dropdown-input-clear js-dropdown-input-clear"></i>
        </div>
        <div class="dropdown-content"></div>
        <div class="dropdown-loading">
            <i class="fa fa-spinner fa-spin"></i>
        </div>
    </div>
</div>
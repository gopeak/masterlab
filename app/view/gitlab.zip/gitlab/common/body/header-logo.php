<div class="header-logo">
    <a class="home" title="Masterlab-极致的项目管理工具!" id="logo" href="/dashboard">
        <img src="<?=ROOT_URL?>gitlab/images/logo-s.png" />
    </a>
</div>
